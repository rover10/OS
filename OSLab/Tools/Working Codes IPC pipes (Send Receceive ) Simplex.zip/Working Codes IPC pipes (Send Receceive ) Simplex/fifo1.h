// fifo1.h
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <limits.h>
#include <errno.h>
#define PUBLIC "/tmp/FIFODEMO1_PIPE"
