#include<stdio.h>
int main(){
   for(int i=0;i<5;i++)
      printf("3");
return 0;
}
